
public enum GoodsType {
	Standard, Dangerous, Refrigerated
}
